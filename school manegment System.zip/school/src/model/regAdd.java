
package model;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author VM
 */
public class regAdd {
    
      Statement stmt;
 
public void Form(String fname, String lname, String stu_id, String password, String cpassword)  {
 try {
stmt = DBconnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO register VALUES('"+fname+"', '"+lname+"', '"+stu_id+"', '"+password+"', '"+cpassword+"')");
 } catch (SQLException e) {
 }
}
    

    
    
     /*public void Form1(String fname, String lname, String stu_id, String password, String cpassword) {
        if (!password.equals(cpassword)) {
            System.out.println("Passwords do not match");
            return;
        }

        String query = "INSERT INTO register (fname, lname, stu_id, password,cmpassword) VALUES (?, ?, ?,?, ?)";

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, fname);
            pstmt.setString(2, lname);
            pstmt.setString(3, stu_id);
            pstmt.setString(4, password); 
            pstmt.setString(5, cpassword); // Note: Hash the password before storing it

            pstmt.executeUpdate();
            System.out.println("User registered successfully");
        } catch (SQLException e) {
            e.printStackTrace();  // Consider using a logger instead of printStackTrace
        }
    }*/
    
}
