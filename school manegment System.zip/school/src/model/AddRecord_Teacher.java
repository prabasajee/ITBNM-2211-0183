
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class AddRecord_Teacher {
  Statement stmt;
 
public void Form(String fname, String address, String qualification, String number,String email) {
 try {
stmt = DBconnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO teacher VALUES('"+fname+"', '"+address+"', '"+qualification+"', '"+number+"', '"+email+"')");
 } catch (Exception e) {
 e.printStackTrace();
 }
}  
 public void deleteRecord(String id_noToDelete) {
        try {
            stmt = DBconnection.getStatementConnection();
            stmt.executeUpdate("DELETE FROM teacher WHERE fname = '" + id_noToDelete + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 public void updateRecord(String fname, String address, String qualification,String number, String email) {
        try (Connection conn = DBconnection.getConnection()) {
            String query = "UPDATE teacher SET fname = ?, address = ?, qualification = ?,number=?, email = ? ";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, fname);
            pst.setString(2, address);
            pst.setString(3, qualification);
            pst.setString(4, number);
            pst.setString(5, email);
          
            
            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Record updated successfully!");
            } else {
                System.out.println("No record found with number = " + number);
            }
            
            pst.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }







}
