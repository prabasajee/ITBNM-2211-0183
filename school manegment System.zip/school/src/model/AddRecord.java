
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author VM
 */
public class AddRecord {
    Statement stmt;
 
public void Form(String id_no, String book_name, String subject, String write_name,String Class, String pub_year) {
 try {
stmt = DBconnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO library VALUES('"+id_no+"', '"+book_name+"', '"+subject+"', '"+write_name+"', '"+Class+"','"+pub_year+"')");
 } catch (Exception e) {
 e.printStackTrace();
 }
}

   
    
   public void deleteRecord(String id_noToDelete) {
        try {
            stmt = DBconnection.getStatementConnection();
            stmt.executeUpdate("DELETE FROM library WHERE id_no = '" + id_noToDelete + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateRecord(String id_no, String book_name, String subject, String write_name, String Class, String pub_year) {
        try (Connection conn = DBconnection.getConnection()) {
            String query = "UPDATE library SET book_name = ?, subject = ?, write_name = ?, class = ?, pub_year = ? WHERE id_no = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, book_name);
            pst.setString(2, subject);
            pst.setString(3, write_name);
            pst.setString(4, Class);
            pst.setString(5, pub_year);
            pst.setString(6, id_no);
            
            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Record updated successfully!");
            } else {
                System.out.println("No record found with id_no = " + id_no);
            }
            
            pst.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    

}
