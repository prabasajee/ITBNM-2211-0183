
package model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author VM
 */
public class DBSearch {
    Statement stmt;
    ResultSet rs;
public ResultSet searchLogin(String usName) {
     try {
        stmt = (Statement) DBconnection.getStatementConnection();
        String name = usName;
//Execute the Query
          rs = stmt.executeQuery("SELECT * FROM register where stu_id='" + name + "'");
         } catch (Exception e) {
         e.printStackTrace();
         }
         return rs;
 }

   public ResultSet adminLogin(String usName) {
     try {
        stmt = (Statement) DBconnection.getStatementConnection();
        String name = usName;
//Execute the Query
          rs = stmt.executeQuery("SELECT * FROM admin where username='" + name + "'");
         } catch (Exception e) {
         e.printStackTrace();
         }
         return rs;
 } 
   
   
   
   public ResultSet searchStudents(){
 try{
 stmt = DBconnection.getStatementConnection();
 rs = stmt.executeQuery("SELECT * FROM library");
 }
 catch(Exception e){
 
 }
 return rs;
 }

   
     
   public ResultSet Teacher(){
 try{
 stmt = DBconnection.getStatementConnection();
 rs = stmt.executeQuery("SELECT * FROM teacher");
 }
 catch(Exception e){
 
 }
 return rs;
 }
   
    public ResultSet Class(){
 try{
 stmt = DBconnection.getStatementConnection();
 rs = stmt.executeQuery("SELECT * FROM Class_1");
 }
 catch(Exception e){
 
 }
 return rs;
 }
   
}
