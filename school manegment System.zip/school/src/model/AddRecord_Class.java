
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author VM
 */
public class AddRecord_Class {
    Statement stmt;
 
public void Form(String sub_name, String Class,String teacher_name ,String Time) {
 try {
stmt = DBconnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO Class_1 VALUES('"+sub_name+"', '"+Class+"','"+teacher_name+"', '"+Time+"')");
 } catch (Exception e) {
 e.printStackTrace();
 }
}  
 public void deleteRecord(String id_noToDelete) {
          try {
        Connection conn = DBconnection.getConnection();
        String sql = "DELETE FROM class_1 WHERE sub_name = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id_noToDelete);
        pstmt.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        DBconnection.closeConnection();
          }
    }

 public void updateRecord(String sub_name, String Class, String teacher_name,String Time) {
        try (Connection conn = DBconnection.getConnection()) {
            String query = "UPDATE class_1 SET sub_name = ?, Class = ?, teacher_name = ?,Time =? WHERE sub_name = ? ";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, sub_name);
            pst.setString(2, Class);
            pst.setString(3, teacher_name);
            pst.setString(4, Time );
            
          
            
            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Record updated successfully!");
            } else {
                System.out.println("No record found with number = " + sub_name);
            }
            
            pst.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void updateRecord(String currentSubName, String newSubName, String className, String teacher_name, String time) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }











   
    }

