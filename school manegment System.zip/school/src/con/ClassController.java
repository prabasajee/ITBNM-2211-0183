
package con;

import javax.swing.JOptionPane;

public class ClassController {
    public static void Form(String sub_name, String Class,String teacher_name ,String Time) {
    new model.AddRecord_Class().Form(sub_name,Class,teacher_name,Time);
   JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", JOptionPane.INFORMATION_MESSAGE);
}

    public static class Form {

        public Form() {
        }
    }
    
    
    
}