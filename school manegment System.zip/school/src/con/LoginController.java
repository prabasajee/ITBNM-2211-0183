
package con;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.DBSearch;
import model.DBconnection;
import view.login;
import view.user_dashboard;


public class LoginController {
    public static void login(String usName, String pass) {
    try {
         String username = null; // initial value of the username
         String password = null; // initial value of the password
         ResultSet rs = new DBSearch().searchLogin(usName);
//Process the Query
        while (rs.next()) {
        username = rs.getString("stu_id"); 

        password = rs.getString("password"); 
         }
         if (username != null && password != null) {
         if (password.equals(pass)) {
         System.out.println("Login Successfull");
          login.getFrames()[0].dispose();
         new user_dashboard().setVisible(true);
         } else {
        JOptionPane.showMessageDialog(null, "Please check the credentials", "Error", JOptionPane.ERROR_MESSAGE);
       }
     }  
 else {
JOptionPane.showMessageDialog(null, "Please check the Credentials", "Error", JOptionPane.ERROR_MESSAGE);
 }
 DBconnection.closeCon();
 } catch (SQLException ex) { 
Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
 }
 }

    
}
