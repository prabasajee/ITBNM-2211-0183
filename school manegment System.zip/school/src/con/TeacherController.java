
package con;

import javax.swing.JOptionPane;

/**
 *
 * @author VM
 */
public class TeacherController {
    public static void Form(String fname, String address, String qualification, String number, String email) {
    new model.AddRecord_Teacher().Form(fname,address,qualification,number,email);
    JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", JOptionPane.INFORMATION_MESSAGE);
}

    public static class Form {

        public Form() {
        }
    }
}
