
package con;

import javax.swing.JOptionPane;

/**
 *
 * @author VM
 */
public class regController {
       public static void Form(String fname, String lname, String stu_id, String password, String cpassword) {
       
   
        // Validate password conditions
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password must be between 8 to 12 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character.",
                    "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return; // Exit method if password is invalid
        }

        // Check if password and confirm password match
        if (!password.equals(cpassword)) {
            JOptionPane.showMessageDialog(null, "Passwords do not match. Please re-enter the passwords.",
                    "Password Mismatch", JOptionPane.ERROR_MESSAGE);
            return; // Exit method if passwords do not match
        }

        // Assuming model.regAdd.Form() handles the registration logic
        new model.regAdd().Form(fname, lname, stu_id, password, cpassword);

        // Display success message using JOptionPane
        JOptionPane.showMessageDialog(null, "New user has been registered successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // Password validation method
    public static boolean isValidPassword(String password) {
        // Password length should be between 8 and 20 characters
        if (password.length() < 8 || password.length() > 12) {
            return false;
        }

        // Password should contain at least one uppercase letter, one lowercase letter, one digit, and one special character
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(ch)) {
                hasLowercase = true;
            } else if (Character.isDigit(ch)) {
                hasDigit = true;
            } else if (isSpecialCharacter(ch)) {
                hasSpecialChar = true;
            }
        }

        return hasUppercase && hasLowercase && hasDigit && hasSpecialChar;
    }

    // Method to check if a character is a special character
    private static boolean isSpecialCharacter(char ch) {
        // Define your set of special characters here
        String specialCharacters = "!@#$%^&*()-_=+\\|[{]};:'\",<.>/?";

        return specialCharacters.contains(String.valueOf(ch));
    }

 
  
}
