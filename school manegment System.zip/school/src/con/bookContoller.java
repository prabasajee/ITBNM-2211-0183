
package con;

import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import model.DBconnection;

/**
 *
 * @author VM
 */
public class bookContoller {
    public static void Form(String id_no, String book_name, String subject, String write_name, String Class,String pub_year) {
    new model.AddRecord().Form(id_no,book_name,subject,write_name,Class,pub_year);
 JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", JOptionPane.INFORMATION_MESSAGE);
}
   
public static void Form_1(String id, String bookName, String subject, String writeName, String class_b, String pubYear) {
     try {
        // Get a statement object
        Statement stat = DBconnection.getStatementConnection();
        
        // Example query
        String query = "INSERT INTO your_table_name (id_no, book_name, subject, write_name, class, pub_year) VALUES ('"
                + id + "', '" + bookName + "', '" + subject + "', '" + writeName + "', '" + class_b + "', '" + pubYear + "')";
        
        // Execute the query
        int rowsAffected = stat.executeUpdate(query);
        
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Data Saved Successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Failed to save data.");
        }
        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "SQL Error: " + ex.getMessage());
    }

}
}
